class Theme:
    PRIMARY = "#1E88E5"
    SECONDARY = "#424242"
    SUCCESS = "#43A047"
    DANGER = "#E53935"
    WARNING = "#FB8C00"
    INFO = "#00ACC1"
    LIGHT = "#F5F5F5"
    DARK = "#212121"
    
    BG_COLOR = "#121212"
    FG_COLOR = "#FFFFFF"
    BUTTON_COLOR = "#1E88E5"
    BUTTON_HOVER = "#1565C0"
    
    FONT_FAMILY = "Segoe UI"
    FONT_SIZE = 12
    FONT_SIZE_LARGE = 16
    FONT_SIZE_SMALL = 10